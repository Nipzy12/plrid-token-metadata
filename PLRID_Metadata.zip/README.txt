This ZIP contains metadata for the Palmora ID (PLRID) token on Solana.

Files:
- PLRID.json : The token metadata (name, symbol, decimals, logoURI, etc)
- Use this file to submit token info to platforms or wallets that support custom token metadata.

Logo hosted on: https://i.imgur.com/KOMH5ms.png